
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/v1")
public class RestStoritve extends javax.ws.rs.core.Application {

}
